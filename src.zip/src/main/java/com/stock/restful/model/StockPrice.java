package com.stock.restful.model;

import java.sql.Time;
import java.util.Date;

public class StockPrice {
	private String code;
	private String stockExchange;
	private float price;
	private Date date;
	private Time time;
	public StockPrice() {
		super();
		// TODO Auto-generated constructor stub
	}
	public StockPrice(String code, String stockExchange, float price, Date date, Time time) {
		super();
		this.code = code;
		this.stockExchange = stockExchange;
		this.price = price;
		this.date = date;
		this.time = time;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getStockExchange() {
		return stockExchange;
	}
	public void setStockExchange(String stockExchange) {
		this.stockExchange = stockExchange;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Time getTime() {
		return time;
	}
	public void setTime(Time time) {
		this.time = time;
	}
	@Override
	public String toString() {
		return "StockPrice [code=" + code + ", stockExchange=" + stockExchange + ", price=" + price + ", date=" + date
				+ ", time=" + time + "]";
	}
	

}
